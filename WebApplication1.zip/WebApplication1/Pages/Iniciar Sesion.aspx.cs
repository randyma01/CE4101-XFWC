﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using Tweetinvi;

namespace WebApplication1.Pages
{
    public partial class Iniciar_Sesion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button_log_in_Click(object sender, EventArgs e)
        {
            //string connectionString1 = "";
            //connectionString1 = System.Configuration.ConfigurationManager.ConnectionStrings["server=localhost;user id=root;database=xfifadb;password=tavo11"].ToString(); 
            /*
            MySqlConnectionStringBuilder csb = new MySqlConnectionStringBuilder();
            csb.Server = "localhost";
            csb.Database = "xfifadb";
            csb.UserID = "root";
            csb.Password = "tavo11";
            csb.IntegratedSecurity = false;
            */

            MySqlConnection mySqlConnection = new MySqlConnection("server=localhost; user id=root; database=xfifadb; password=tavo11; SslMode = none");

            mySqlConnection.Open();


            MySqlCommand sqlCommand = new MySqlCommand("SELECT * FROM Usuario", mySqlConnection);
            MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);

            DataView dataView;
            DataSet dataSet = new DataSet();
            sqlDataAdapter.Fill(dataSet);

            dataView = dataSet.Tables[0].DefaultView;
            string text_user_name;
            bool IsValid = false;

            foreach (DataRowView datarow in dataView)
            {
                // Extract e-mail address from the current row
                text_user_name = datarow["NombreUsuario"].ToString();
                // Compare e-mail address against user's entry
                if (text_user_name == input_user_name.Text.ToString())
                {
                    IsValid = true;
                }
            }

            if (!IsValid)
            {
                AlertDialog.Text = "Error - no se encuentra en el sistema";

            }
            else
            {
                AlertDialog.Text = "Bienvenido " + input_user_name.Text.ToString() + " !!";
            }



            sqlCommand.Dispose();
            mySqlConnection.Close();


            // = input_user_name.Text + " / " + input_password.Text;
        }

        protected void Button_sign_up_Click(object sender, EventArgs e)
        {
            Auth.SetUserCredentials("oX9Xp2g8Nhs7UY3e5shyiIcWx", "KMVj8nQ4ERXlVr00OXKUhDhm1jiglQr8VGkR8iiJp8WZcRAhdk", "1000630161497260032-pvKGYqAxUxZNYXBdGZV9zuDzyxyaNt", "GDHpnwhMJoklIx4S3vTWI75ralLUe5aaEy9i3vTAImkdZ");

            var user = Tweetinvi.User.GetAuthenticatedUser();
            Console.WriteLine(user);

            var tweet = Tweet.PublishTweet("Bienvenido a X-FIFA World Cup!!!");

        }
    }
    
}